
t4 = function() {
  lib.uib20100.configura_info(
    num_taller=4,
    rubrica="Entrega el fitxer .Rmd i l'informe .html generat. A l'informe, explica
           el codi que utilitzis i el resultat que has obtingut.",
    clau=76416
  )

  inicialitzacio.pollets = function() {
    dades = data.frame(
      pollets_per_adulta = sample(c(3,4,5), size=1),
      mortalitat_pollets = sample(c(0.6, 0.7, 0.8), size=1),
      mortalitat_joves = sample(c(0.25, 0.30, 0.40), size=1),
      mortalitat_adultes = sample(c(0.10, 0.15, 0.20), size=1),
      transicio_joves = sample(c(0.90, 0.95), size=1),
      inicial_pollets = sample(c(10, 12, 14), size=1),
      inicial_joves = sample(c(5, 6), size=1),
      inicial_adultes = sample(c(2, 3), size=1)
    )
    return(dades)
  }

  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=1,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "La vida de l'àguila peixatera es pot dividir en tres etapes: pollet, jove i adult.
        Les àguiles adultes estan en l'etapa reproductiva primària i tenen de mitjana %d nous
        pollets cada any. Les àguiles joves només crien 1 pollet a l'any i els pollets no
        tenen pollets. S'ha observat que aproximadament el %d%% d'àguiles adultes moren cada
        any, mentre que la mortalitat de les àguiles joves és d'un %d%% anualment. Aproximadament
        un %d%% de les àguiles joves que sobreviuen es mantenen en aquesta etapa a l'any següent,
        i totes les altres que sobreviuen transicionen a una etapa adulta. Finalment, només
        el %d%% de pollets sobreviuen i transicionen a àguiles joves cada any. Suposem que
        inicialment tenim %d pollets, %d àguiles joves i %d adultes.

        Siguin $x_n$, $y_n$, $z_n$ el nombre de pollets, àguiles joves i adultes passats $n$ anys.

        Donau la matriu M de l'equació malthusiana matricial que modela la població de l'àguila
        peixatera i explicau breument com l'heu obtinguda.
        ",
        dades$pollets_per_adulta,
        dades$mortalitat_adultes*100, dades$mortalitat_joves*100,
        100 - dades$transicio_joves*100,
        100 - dades$mortalitat_pollets*100,
        dades$inicial_pollets,
        dades$inicial_joves,
        dades$inicial_adultes))
    },
    fun_comprova = function(dades, M) {
      matriu_esperada = matrix(c(
        0, 1, dades$pollets_per_adulta,
        1-dades$mortalitat_pollets, (1-dades$mortalitat_joves)*(1-dades$transicio_joves), 0,
        0, (1-dades$mortalitat_joves)*dades$transicio_joves, 1-dades$mortalitat_adultes
      ), ncol=3, byrow=TRUE)
      check = lib.uib20100.utils.check.matrix(matriu_esperada, M)
      if("error" %in% names(check)) {return(list(check$error))}
      return(check$punts)
    }
  )


  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=2,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "Seguint amb les dades de l'apartat anterior, calculau amb R quina és la
        població d'àguiles al cap de tres anys."))
    },
    fun_comprova = function(dades, num_pollets, num_joves, num_adultes) {
      errlst = list()
      errlst = append(errlst, lib.uib20100.utils.is.number(num_pollets))
      errlst = append(errlst, lib.uib20100.utils.is.number(num_joves))
      errlst = append(errlst, lib.uib20100.utils.is.number(num_adultes))

      M = matrix(c(
        0, 1, dades$pollets_per_adulta,
        1-dades$mortalitat_pollets, (1-dades$mortalitat_joves)*(1-dades$transicio_joves), 0,
        0, (1-dades$mortalitat_joves)*dades$transicio_joves, 1-dades$mortalitat_adultes
      ), ncol=3, byrow=TRUE)
      v0 = matrix(c(
        dades$inicial_pollets, dades$inicial_joves, dades$inicial_adultes
      ), ncol=1)
      v3 = M %*% M %*% M %*% v0
      if( length(errlst) != 0 ) {
        return(errlst)
      }
      check1 = lib.uib20100.utils.check.number(v3[1], num_pollets)
      check2 = lib.uib20100.utils.check.number(v3[2], num_joves)
      check3 = lib.uib20100.utils.check.number(v3[3], num_adultes)

      if("error" %in% names(check1)) {return(list(check1$error))}
      if("error" %in% names(check2)) {return(list(check2$error))}
      if("error" %in% names(check3)) {return(list(check3$error))}
      return((check1$punts + check2$punts + check3$punts)/3)
    }
  )


  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=3,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "Des del 7 de setembre de 2020 entre els alumnes de la UIB ha corregut el fals rumor
        de què RStudio es deixarà d'ensenyar als alumnes de Matemàtiques I a partir del curs
        2021/22. Cada setmana, un alumne que es pensa que el rumor és cert els hi explica a 4
        persones que encara no saben res. D'aquestes 4 persones, només 2 el creuen i els altres
        2 passen a pensar que no és veritat ja que RStudio és molt útil. Per una altra banda,
        els que saben que el rumor és fals cada setmana avisen a 3 persones que encara no saben
        res, però només 2 li fan cas i l'altra pensa que el rumor és cert. D'altra banda, cada
        setmana un 75%% d'alumnes dels que es creuen el rumor i un 60%% dels que no se'l creuen,
        es cansen de la polèmica i deixen de xerrar del tema.

        Diguem $a_n$ i $b_n$ al nombre d'alumnes que es creu el rumor i no se'l creu, respectivament,
        cada setmana a partir del 7 de setembre de 2020. Suposem que inicialment tot va començar
        amb 1 alumne que es va creure que el rumor era cert.

        Donau la matriu M de l'equació malthusiana matricial que modela les poblacions d'estudiants
        que creuen i no creuen el rumor."))
    },
    fun_comprova = function(dades, M) {
      matriu_esperada = matrix(c(
        2.25, 1, 2, 2.4
      ), ncol=2, byrow=TRUE)
      check = lib.uib20100.utils.check.matrix(matriu_esperada, M)
      if("error" %in% names(check)) {return(list(check$error))}
      return(check$punts)
    }
  )


  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=4,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "Seguint amb les dades de l'apartat anterior, utilitzau R per diagonalitzar
        la matriu, i donau l'expressió general de les successions $(a_n)_n$ i $(b_n)_n$."))
    },
    str_codi_per_alumne = "
      # Donada una matriu M, pots calcular la diagonalització amb la següent funció de R:
      eigen(M)
      # En aquest taller, també tens a la teva disposició la funció:
      diagonalitza(M)
    "
  )


  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=5,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "Seguint amb les dades de l'apartat anterior, fes un gràfic on es vegi l'evolució
        de les dues poblacions durant 2 mesos. Comenta, a partir d'aquest gràfic i les expressions
        d'$(a_n)_n$ i $(b_n)_n$, l'evolució de les poblacions quan $n$ es fa gran."))
    },
    str_codi_per_alumne = "
      # La funció plot genera un gràfic nou:
      plot(x=..., y=...)
      # Per afegir més punts sobre el mateix gràfic, utilitza la funció:
      points(x=..., y=...)
    "
  )


  lib.uib20100.afegeixpregunta(
    num_taller=4,
    num_pregunta=5,
    punts=2,
    fun_inicialitzacio_aleatoria = inicialitzacio.pollets,
    fun_pregunta_com_str = function(dades) {
      return(sprintf(
        "Determinau el límit de la ràtio del nombre d'alumnes que és creu el rumor entre
        el nombre d'alumnes que no se'l creu, quan el nombre de setmanes $n$ es fa gran."))
    },
    fun_comprova = function(dades, limit_ratio) {
      valor_esperat = 0.5569600/0.8305393
      check = lib.uib20100.utils.check.number(valor_esperat, limit_ratio)
      if("error" %in% names(check)) {return(list(check$error))}
      return(check$punts)
    }
  )
}
