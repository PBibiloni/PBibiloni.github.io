
###
# TALLERS
###


#' @export
tallers.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  lib.uib20100.configura(taller=taller, alumne=alumne, clau=clau)
}

#' @export
tallers.enunciat = function(num_pregunta, versio=NULL) {
  lib.uib20100.enunciat(num_pregunta=num_pregunta, versio=versio)
}

#' @export
tallers.comprova = function(num_pregunta, versio=NULL, ...) {
  lib.uib20100.comprova(num_pregunta=num_pregunta, versio=versio, ...)
}

#' @export
tallers.finalitza = function() {
  lib.uib20100.mostra_resum()
}


###
# DIAGONALITZACIÓ
###

#' @export
diagonalitza = function(A, decimals=2) {
  if(is.null(dim(A))) {stop("Has proporcionat una matriu!")}
  if(dim(A)[1] != dim(A)[2]) {stop("La matriu ha de ser quadrada!")}

  n = dim(A)[1]
  descomposicio = eigen(A)
  D = diag(descomposicio$values)
  P = descomposicio$vectors
  for(i in seq(1, n)) {
    col = P[ , i]
    P[ , i] = P[ , i] / min(abs(col[abs(col) > 1e-5]))
    idx_first_nonzero = which(Re(P[ , i]) != 0)[1]
    if(Re(P[idx_first_nonzero, i]) < 0) {
      P[ , i] = -P[ , i]
    }
  }

  # Comprova si és diagonalitzable, canviant P i D
  es_diagonalitzable = TRUE
  etiqueta_matriu_diagonal = "D = "
  for(i in seq(2, n)) {
    v =
    if(qr(P[, 1:i])$rank != i) {
      es_diagonalitzable = FALSE
      etiqueta_matriu_diagonal = "E = "
      D[i-1, i] = 1
      # Trobar vector v tal que (A- lambda*I)*v = v_anterior
      v = qr.coef(qr(A - descomposicio$values[i]*diag(n)), P[ , i-1])
      posicions_na = is.na(v)
      v[posicions_na] <- 0
      P[ , i] = v
      num_iteracio = 0
      while(qr(P[, 1:i])$rank != i) {
        P[posicions_na, i] <- sample(1:num_iteracio, sum(posicions_na))
        if(num_iteracio > 100) {
          stop("No s'ha pogut calcular la forma normal d'aquesta matriu (no s'han trobat VEPs suficients)")
        }
      }
    }
  }
  # Reordenam els VEPs/VAPs per a que els 1 surtin sota la diagonal:
  P = P[ , c(n:1), drop = FALSE]
  D = D[c(n:1), c(n:1), drop = FALSE]

  # Calcula P^{-1}
  Pinv = solve(P)
  detP = prod(abs(Re(diag(qr(P)$qr))))

  # Comprova que abs(A - PDP^-1) = 0 (per el cas complexe)
  resultat_correcte = isTRUE(all.equal(
    matrix(rep(0, length(A)), ncol=n),
    abs(A - P %*% D %*% Pinv)))
  if(!resultat_correcte) {
    stop("No s'ha pogut calcular la forma normal d'aquesta matriu (A != PDP^{-1})")
  }

  if(knitr::is_html_output() | knitr::is_latex_output()) {
    dades = list(
      "\\text{Matriu} = " = A,
      etiqueta_matriu_diagonal = D,
      "P = " = P,
      "P^{-1} = " = Pinv,
      "P^{-1} = \\frac{1}{det(P)} \\cdot P', \\text{ on } P'=" = Pinv*detP,
      "\\det(P) = " = detP
    )
    names(dades)[2] = if(es_diagonalitzable) "D = " else "E = "
    tables_html = lapply(seq_along(dades), function(i) {
      sprintf('$%s$', lib.uib20100.utils.matrix2latex(dades[[i]], name=names(dades)[[i]], decimals=decimals))
    })
    return(lib.uib20100.utils.output(
      unname(tables_html),
      header="Descomposici&oacute; diagonal"))
  } else {
    dades = list(
      "Matriu = " = A,
      "Matriu D/E =" = D,
      "P = " = P,
      "P^(-1) = " = Pinv,
      "P^(-1) = 1/det(P) * P', on P'= " = Pinv*detP,
      "det(P) = " = detP
    )
    names(dades)[2] = if(es_diagonalitzable) "D = " else "E = "
    tables_pandoc = lapply(seq_along(dades), function(i) {
      lib.uib20100.utils.matrix2pandoc(dades[[i]], name=names(dades)[[i]], decimals=decimals)
    })
    return(knitr::kables(tables_pandoc, format='pipe'))
  }
}
