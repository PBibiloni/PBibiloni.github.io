
lib.uib20100.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  lib.uib20100.registre.afegeix_config(taller, alumne, clau)
  if(packageVersion("knitr") < "1.29") {
    return(lib.uib20100.utils.outputerror("Executa a la consola (pestanya d'abaix) la instrucció `install.packages(\"knitr\")`, ja que tens una versió desactualitzada."))
  }
  if(is.null(taller)) {
    return(lib.uib20100.utils.outputerror("No has proporcionat el parametre `taller`"))
  }
  if(!is.numeric(taller) | !length(taller)==1) {
    return(lib.uib20100.utils.outputerror("El parametre `taller` ha de ser un unic nombre enter"))
  }
  if(is.null(alumne)) {
    return(lib.uib20100.utils.outputerror("No has proporcionat el parametre `alumne`"))
  }
  if(!is.character(alumne) | !length(alumne)==1) {
    return(lib.uib20100.utils.outputerror("El parametre `alumne` ha de ser una cadena de text"))
  }
  if(alumne == "Cognoms, Nom") {
    return(lib.uib20100.utils.outputerror("El parametre `alumne` ha de ser el teu nom complet"))
  }
  if(is.null(clau)) {
    return(lib.uib20100.utils.outputerror("No has proporcionat el parametre `clau`"))
  }
  if(!is.numeric(clau) | !length(clau)==1) {
    return(lib.uib20100.utils.outputerror("El parametre `clau` ha de ser un unic nombre enter"))
  }
  assign("data.num_taller", NULL, envir=cacheEnv)
  assign("data.alumne", NULL, envir=cacheEnv)
  assign("data.clau", NULL, envir=cacheEnv)
  assign("data.seed", NULL, envir=cacheEnv)

  info = lib.uib20100.get_info(num_taller=taller)
  if(is.null(info)) {
    return(lib.uib20100.utils.outputerror("El nombre de taller no es correcte"))
  }
  if(info[["clau"]] != clau) {
    return(lib.uib20100.utils.outputerror("La clau no es correcta"))
  }

  assign("data.num_taller", taller, envir=cacheEnv)
  assign("data.alumne", alumne, envir=cacheEnv)
  assign("data.clau", clau, envir=cacheEnv)

  alumne_chars = utf8ToInt(iconv(alumne, "UTF-8", "UTF-8",sub=''))
  alumne_seed = sum(alumne_chars * seq(3, 1+2*length(alumne_chars), by=2))
  seed = taller + 2 * clau + alumne_seed
  assign("data.seed", seed, envir=cacheEnv)

  stopifnot("El taller no té cap pregunta assignada."=info[["num_preguntes"]]>0)
  lib.uib20100.registre.inicialitza_punts(num_preguntes=info[["num_preguntes"]])

  return(lib.uib20100.mostra_resum(mostra_punts_aconseguits=FALSE))
  output = list(
    alumne = alumne,
    clau = clau
  )
  rubrica = info[["rubrica"]]
  rubrica_extra_punts = info[["rubrica_extra_punts"]]
  if (length(rubrica) > 0) {
    if (rubrica_extra_punts == 0) {
      output[["Rúbrica"]] = rubrica
    } else {
      output[["Rúbrica"]] = sprintf("[%d punts] %s", rubrica_extra_punts, rubrica)
    }
  }
  for (num_p in seq(1, info[["num_preguntes"]])) {
    p = lib.uib20100.getpregunta(num_taller=taller, num_pregunt=num_p)
    k = sprintf("Pregunta %2d", num_p)
    output[[k]] = sprintf("[%d punts]", p[["punts"]])
  }

  lib.uib20100.utils.output(output, header=sprintf("Resum Taller %d", taller))
}

lib.uib20100.enunciat = function(num_pregunta, versio) {
  if(is.null(get("data.seed", envir=cacheEnv))) {
    return(lib.uib20100.utils.outputerror.noconfig())
  }
  pregunta = lib.uib20100.getpregunta(
    num_taller=get("data.num_taller", envir=cacheEnv),
    num_pregunta=num_pregunta,
    versio=versio)
  preg_header = sprintf("Pregunta %2d - Enunciat", num_pregunta)


  if(is.null(pregunta$fun_inicialitzacio_aleatoria)) {
    preg_dades = NULL
  } else {
    set.seed(get("data.seed", envir=cacheEnv))
    preg_dades = pregunta$fun_inicialitzacio_aleatoria()
  }

  caller = parent.frame(2)
  if(is.null(pregunta$fun_variables_per_alumne)) {
    preg_info = NULL
  } else {
    preg_varlists = pregunta$fun_variables_per_alumne(preg_dades)
    preg_varnames = names(preg_varlists)
    for(n in preg_varnames) {
      v = preg_varlists[[n]]
      caller[[n]] = v
    }
    preg_info = paste(preg_varnames, sep="`, `", collapse="`, `")
    preg_info = paste("Tens disponibles les variables: `", preg_info, "`.", sep="")
  }

  if(is.null(pregunta$fun_comprova)) {
    preg_punts = sprintf("%2d (Correcció manual)", pregunta$punts)
  } else {
    preg_punts = sprintf("%2d", pregunta$punts)
  }

  preg_str = pregunta$fun_pregunta_com_str(dades=preg_dades)
  k1 = lib.uib20100.utils.output(list(
    " " = preg_str,
    "Dades:" = preg_info,
    "Punts:" = preg_punts
  ), header=preg_header)

  if(is.null(pregunta$str_codi_per_alumne)) {
    knitr::kables(list(k1))
  } else {
    k2 = lib.uib20100.utils.outputcodi(
      pregunta$str_codi_per_alumne,
      header="Codi d'exemple")
    knitr::kables(list(k1, k2))
  }
}

lib.uib20100.comprova = function(num_pregunta, versio, ...) {
  if(is.null(get("data.seed", envir=cacheEnv))) {
    return(lib.uib20100.utils.outputerror.noconfig())
  }
  pregunta = lib.uib20100.getpregunta(
    num_taller=get("data.num_taller", envir=cacheEnv),
    num_pregunta=num_pregunta,
    versio=versio)
  preg_header = sprintf("Pregunta %2d - Resposta", num_pregunta)

  if(is.null(pregunta$fun_inicialitzacio_aleatoria)) {
    preg_dades = NULL
  } else {
    set.seed(get("data.seed", envir=cacheEnv))
    preg_dades = pregunta$fun_inicialitzacio_aleatoria()
  }

  errlist = list()
  if(is.null(pregunta$fun_comprova)) {
    resp_str = "Pregunta amb correcció manual."
    resp_punts = sprintf("??/%2d", pregunta$punts)
  } else {
    # Check if parameters are found:
    req_args = setdiff(names(formals(pregunta$fun_comprova)), c("dades"))
    available_args = names(list(...))
    if( length(req_args) == length(available_args) &
        length(setdiff(req_args, available_args)) == 0) {
      result = pregunta$fun_comprova(dades=preg_dades, ...)
      if(is.numeric(result)) {
        if(result == 1) {
          resp_str = "Resposta correcta!"
        } else if(result != 0) {
          resp_str = "Resposta parcialment correcta."
        } else {
          resp_str = "Resposta incorrecta."
        }
        resp_punts = sprintf("%4.1f/%2d", pregunta$punts * result, pregunta$punts)
        lib.uib20100.registre.assigna_punts(num_pregunta=num_pregunta, punts=pregunta$punts)
      } else {
        errlist = result
        resp_str = "No has introduït bé la resposta"
        resp_punts = sprintf(" 0/%2d", pregunta$punts)
        knitr::kable(data.frame(Pregunta = "Resposta incorrecta!"))
      }
    } else {
      for( non_arg in setdiff(req_args, available_args)) {
        errlist = append(errlist, sprintf("No has introduït el paràmetre `%s = ...`", non_arg))
      }
      for( non_arg in setdiff(available_args, req_args)) {
        if( non_arg == "") {
          errlist = append(errlist, sprintf("Tots els paràmetres han de tenir nom: `parametre_demanat = ...`", non_arg))
        } else {
          errlist = append(errlist, sprintf("Sobra el paràmetre `%s`", non_arg))
        }
      }
      resp_str = "No has introduït bé la resposta"
      resp_punts = sprintf(" 0/%2d", pregunta$punts)
      knitr::kable(data.frame(Pregunta = "Resposta incorrecta!"))
    }

  }

  if( length(errlist) > 0 ) {
    names(errlist) <- sprintf("Error %2d", 1:length(errlist))
  }

  preg_str = pregunta$fun_pregunta_com_str(dades=preg_dades)
  lib.uib20100.utils.output(append(list(
    " " = preg_str,
    "Correcci&oacute;" = resp_str,
    "Punts" = resp_punts
  ), errlist), header=preg_header)
}

lib.uib20100.mostra_resum = function(mostra_punts_aconseguits=TRUE) {
  if(is.null(get("data.seed", envir=cacheEnv))) {
    return(lib.uib20100.utils.outputerror.noconfig())
  }
  num_taller = get("data.num_taller", envir=cacheEnv)

  output = list(
    Alumne = get("data.alumne", envir=cacheEnv),
    Clau = get("data.clau", envir=cacheEnv)
  )

  info = lib.uib20100.get_info(num_taller=num_taller)
  str_rubrica = info[["rubrica"]]
  rubrica_extra_punts = info[["rubrica_extra_punts"]]
  if(!is.null(str_rubrica) > 0 | rubrica_extra_punts != 0) {
    if (is.null(str_rubrica)) {
      str_rubrica = ""
    }
    if (rubrica_extra_punts != 0) {
      if(mostra_punts_aconseguits) {
        str_punts = sprintf("[---/%2d punts] Correcció manual. ", rubrica_extra_punts)
      } else {
        str_punts = sprintf("[%2d punts] Correcció manual. ", rubrica_extra_punts)
      }
    } else {
      str_punts = ""
    }
    output[["Rúbrica"]] = sprintf("%s%s", str_punts, str_rubrica)
  }

  info = lib.uib20100.get_info(num_taller)
  punts = get("data.registre.punts", envir=cacheEnv)
  punts_obtinguts = 0
  punts_autocorregits = 0
  for (num_p in seq(1, info[["num_preguntes"]])) {
    p = lib.uib20100.getpregunta(num_taller, num_p)
    if(is.null(p$fun_comprova)) {
      v_substr = " Correcció manual."
    } else {
      v_substr = ""
      punts_obtinguts = punts_obtinguts + punts[[num_p]]
      punts_autocorregits = punts_autocorregits + p[["punts"]]
    }
    k = sprintf("Pregunta %2d", num_p)
    if(!mostra_punts_aconseguits) {
      v = sprintf("[%2d punts]%s", p[["punts"]], v_substr)
    } else if(is.null(p$fun_comprova)) {
      v = sprintf("[---/%2d punts]%s", p[["punts"]], v_substr)
    } else {
      v = sprintf("[%2d/%2d punts]", punts[[num_p]], p[["punts"]])
    }
    output[[k]] = v
  }
  if(mostra_punts_aconseguits) {
    output[["Correcció automàtica"]] = sprintf("[%2d/%2d punts]",
                                               punts_obtinguts,
                                               punts_autocorregits)
    output[[" "]] = "(Podria ser modificat durant la correcció manual)"
  }

  for (c in get("data.registre.configs", envir=cacheEnv)) {
    k = sprintf("Config %s", c[["timestamp"]])
    v = sprintf("Taller: %2d, Alumne: %s, Clau: %d",
                c[["taller"]], c[["alumne"]], c[["clau"]])
    # TODO: only hidden, preserved info among executions # output[[k]] = v
  }

  lib.uib20100.utils.output(
    output, header=sprintf("Taller %d -- Resum", num_taller))
}

lib.uib20100.getpregunta = function(num_taller, num_pregunta, versio=NULL) {
  set.seed(get("data.seed", envir=cacheEnv) + num_taller + num_pregunta)
  categoria = sprintf("%04d-%04d", num_taller, num_pregunta)

  lib.uib20100.preguntes = get("data.p", envir=cacheEnv)
  preguntes_cat = lib.uib20100.preguntes[[categoria]]
  if(is.null(versio)) {
    return(sample(preguntes_cat, 1)[[1]])
  }
  if(versio > length(preguntes_cat)) {
    stop("No hi ha tantes versions per aquesta pregunta.")
  }
  return(preguntes_cat[[versio]])
}

lib.uib20100.afegeixpregunta = function(
  # Identificació de la pregunta.
  # Si afegim més d'una pregunta per un num_taller/num_preg, es seleccionarà una a l'atzar
  num_taller,     # Integer
  num_pregunta,   # Integer
  punts,    # Totes les del mateix num_taller/num_pregunta haurien de tenir el mateix valor en punts
  # Contingut de la pregunta.
  # Funcions que permeten aleatoritzar les dades i comprovar la resposta.
  fun_inicialitzacio_aleatoria, # dades <- function(). Obviar si no cal.
  fun_pregunta_com_str,         # enunciat_str <- function(dades)
  fun_variables_per_alumne,     # list_variables_to_give <- function(dades). Obviar si no cal.
  str_codi_per_alumne,          # function(), no s'executarà (només es mostrarà el codi). Obviar si no cal.
  fun_comprova                  # boolean_truefalse <- function(dades, resposta). Obviar si la correcció és manual.
) {
  lib.uib20100.preguntes = get("data.p", envir=cacheEnv)

  lib.uib20100.configura_info(num_taller=num_taller, num_pregunta=num_pregunta)
  if(missing(fun_inicialitzacio_aleatoria)){
    fun_inicialitzacio_aleatoria = NULL
  }
  if(missing(fun_variables_per_alumne)){
    fun_variables_per_alumne = NULL
  }
  if(missing(str_codi_per_alumne)){
    str_codi_per_alumne = NULL
  }
  if(missing(fun_comprova)){
    fun_comprova = NULL
  }
  categoria = sprintf("%04d-%04d", num_taller, num_pregunta)
  preguntes_cat = lib.uib20100.preguntes[[categoria]]
  if(is.null(preguntes_cat)) {
    preguntes_cat = list()
  }
  num_versio = length(preguntes_cat)+1
  preguntes_cat[[sprintf("versio_%d", num_versio)]] = list(
      num_taller = num_taller,
      num_pregunta = num_pregunta,
      num_versio = num_versio,
      punts = punts,
      fun_inicialitzacio_aleatoria = fun_inicialitzacio_aleatoria,
      fun_pregunta_com_str = fun_pregunta_com_str,
      fun_variables_per_alumne = fun_variables_per_alumne,
      str_codi_per_alumne = str_codi_per_alumne,
      fun_comprova = fun_comprova)

  lib.uib20100.preguntes[[categoria]] = preguntes_cat
  assign("data.p", lib.uib20100.preguntes, envir=cacheEnv)
}

lib.uib20100.configura_info = function(
  num_taller,
  clau=NULL,
  rubrica=NULL,
  rubrica_extra_punts=NULL,
  num_pregunta=NULL
) {
  info_tallers = get("data.t", envir=cacheEnv)
  info = info_tallers[[sprintf("%d", num_taller)]]
  if( is.null(info) ) {
    info = list(
      num_taller = num_taller,
      clau=0,
      rubrica = NULL,
      rubrica_extra_punts = 0,
      num_preguntes = 0
    )
  }

  if ( length(clau) > 0 ) {
    stopifnot("La clau ja s'ha inicialitzat"=clau!=0)
    info[["clau"]] = clau
  }

  if ( length(rubrica) > 0 ) {
    stopifnot("El parametre `rubrica` ha de ser una cadena de text"=is.character(rubrica) & length(rubrica)==1)
    info[["rubrica"]] = rubrica

    if ( length(rubrica_extra_punts) > 0 ) {
      stopifnot("El parametre `rubrica_extra_punts` ha de ser un unic nombre enter"=is.numeric(rubrica_extra_punts) & length(rubrica_extra_punts)==1)
      info[["rubrica_extra_punts"]] = rubrica_extra_punts
    }
  } else if ( length(rubrica_extra_punts) > 0 ) {
    stop("No podem assignar `rubrica_extra_punts` sense `rubrica`")
  }

  if ( length(num_pregunta) > 0 ) {
    stopifnot("El parametre `num_pregunta` ha de ser un unic nombre enter"=is.numeric(num_pregunta) & length(num_pregunta)==1)
    if (num_pregunta == info[["num_preguntes"]] + 1) {
      info[["num_preguntes"]] = num_pregunta
    } else if (num_pregunta > info[["num_preguntes"]] + 1) {
      stop(sprintf("Intentam registrar la pregunta %2d, pero al taller %d
                    nomes existeix fins la pregunta %2d",
                   num_pregunta, num_taller, info[["num_preguntes"]]))
    }
  }

  info_tallers[[sprintf("%d", num_taller)]] = info
  assign("data.t", info_tallers, envir=cacheEnv)
}

lib.uib20100.get_info = function(num_taller=NULL) {
  if(is.null(num_taller)) {
    num_taller = get("data.num_taller", envir=cacheEnv)
  }
  info = get("data.t", envir=cacheEnv)
  return(info[[sprintf("%d", num_taller)]])
}

lib.uib20100.registre.inicialitza_punts = function(num_preguntes) {
  punts = list()
  for(num_p in seq(1, num_preguntes)) {
    punts[[num_p]] = 0
  }
  assign("data.registre.punts", punts, envir=cacheEnv)
}

lib.uib20100.registre.assigna_punts = function(num_pregunta, punts) {
  registre.punts = get("data.registre.punts", envir=cacheEnv)
  registre.punts[[num_pregunta]] = max(punts, registre.punts[[num_pregunta]])
  assign("data.registre.punts", registre.punts, envir=cacheEnv)
}

lib.uib20100.registre.afegeix_config = function(taller, alumne, clau) {
  cs = get("data.registre.configs", envir=cacheEnv)
  c = list(
    taller=taller,
    alumne=alumne,
    clau=clau,
    timestamp=Sys.time()
  )
  cs[[sprintf("%03d", length(cs))]] = c
  assign("data.registre.configs", cs, envir=cacheEnv)
}

cacheEnv <- new.env()

assign("data.num_taller", NULL, envir=cacheEnv)
assign("data.alumne", NULL, envir=cacheEnv)
assign("data.clau", NULL, envir=cacheEnv)
assign("data.seed", NULL, envir=cacheEnv)

assign("data.t", list(), envir=cacheEnv)
assign("data.p", list(), envir=cacheEnv)

assign("data.registre.punts", list(), envir=cacheEnv)
assign("data.registre.configs", list(), envir=cacheEnv)

